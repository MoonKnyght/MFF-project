# MFF Companion — deployable app v1

A phone-first Next.js + Supabase application built from the Cynicalex Mega Guides-derived database.

## What works immediately
- 275-character searchable database using bundled fallback data
- Character detail drawer: uniform, advancement, build, CTPs, ISO, artifact, T4 performance, WBL, Shadowland+, Dispatch and Story data
- Responsive phone UI
- Installable PWA manifest + service worker
- Supabase-ready APIs
- Email magic-link authentication page
- Private roster schema with Row Level Security

## Run locally
1. Install Node.js 22+.
2. `npm install`
3. `npm run dev`
4. Open `http://localhost:3000`

The database search works before Supabase is configured because `data/seed.characters.json` is used as a fallback.

## Connect Supabase
1. Create a Supabase project.
2. Copy `.env.example` to `.env.local` and fill in the project URL and publishable key.
3. Run `supabase/migrations/001_initial.sql` in the Supabase SQL editor (or through Supabase CLI migrations).
4. Put the server-only Supabase secret key in your shell as `SUPABASE_SECRET_KEY`.
5. Run `npm run seed`.
6. Restart `npm run dev`.

**Never put `SUPABASE_SECRET_KEY` in browser code or commit it.**

## Deploy
Vercel is the easiest deployment target for this Next.js app. Add the two public Supabase environment variables in Vercel. The secret key is only required for the import/seed process and should remain server-side.

## Data update pipeline
Current: spreadsheet → normalized export → `data/seed.characters.json` → `npm run seed` → Supabase.

Recommended next automation: make the spreadsheet importer a repeatable script that validates changed character/uniform/build/game-mode rows before upserting them. That will let a new guide version update the production database without rebuilding the UI.

## Important data rule
Current/latest uniforms are safe to display first. Older uniforms remain preserved but exact chronology stays unclaimed until release-date/version metadata is added.

## Player roster (v2)
The app now supports roster ownership, player tier/level, owned uniform, equipped CTP, artifact ownership, and notes. Without Supabase it stores this privately in browser localStorage. With Supabase Auth connected it uses `player_roster` with RLS.

Run `supabase/migrations/002_roster_build_fields.sql` after the initial migration to add CTP and artifact ownership fields.

The main character search includes a **My roster** filter, so database recommendations can be narrowed to owned characters. The next layer can combine these saved records with WBL/Dispatch/Shadowland restrictions to produce account-specific recommendations.

## Roster-aware recommendations

The `/recommend` page ranks guide matches for World Boss Legend, Shadowland+, and Dispatch against the player's saved roster. The engine keeps source roles (`required`, `recommended`, `support`) separate and adds a readiness summary from the player's saved tier, uniform, CTP, and artifact status. It does not invent eligibility rules that are absent from the guide source.

The app also falls back to the bundled 275-character dataset if Supabase is configured but the cloud tables have not been seeded yet.

## v4: Roster-aware Team Builder

`/team-builder` assembles ranked three-character teams for World Boss Legend, Shadowland+, and Dispatch. It separates DPS, Lead, and Support roles; uses the source guide's stage links; factors in tier-list leadership/support tags, mode scores, and the player's saved roster/build state; and avoids duplicate characters within a team.

The match score is a recommendation heuristic, not a guarantee that a team will clear content. Stage restrictions and the source guide remain authoritative where available.

## v5: Saved Teams, Clear Tracking, Gap Analysis
- Save any Team Builder suggestion locally or to the signed-in Supabase account.
- Save + mark cleared records the selected mode/boss/stage as completed.
- `/progress` summarizes roster size, saved teams, tracked clears, and highest-impact next builds.
- Gap Analysis counts uncleared stages where the player already owns two guide-eligible characters and one additional character creates a three-character eligible pool. It is a planning heuristic, not a guaranteed-clear claim.
- Migration `004_saved_teams_progress.sql` adds private `saved_teams` and `stage_clears` tables with per-user RLS and removes the roster→cloud-character FK so roster tracking works while the bundled database remains authoritative.
