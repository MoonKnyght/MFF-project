import seed from '@/data/seed.characters.json';
import type { Character } from './types';
import { serverSupabase } from './supabase';
const local = seed as Character[];
function searchLocal(q='',type='',tier=''){const needle=q.toLowerCase().trim();return local.filter(c=>(!needle||`${c.name} ${c.aliases||''} ${c.latestUniform||''} ${c.metaCtpPve||''} ${c.metaCtpPvp||''}`.toLowerCase().includes(needle))&&(!type||c.type===type)&&(!tier||String(c.highestTier||'').toLowerCase().includes(tier.toLowerCase()))).slice(0,275)}
export async function searchCharacters(q='',type='',tier='') {
  const db=serverSupabase();
  if(!db){
    return searchLocal(q,type,tier);
  }
  let query=db.from('characters').select('*').order('name');
  if(q) query=query.or(`name.ilike.%${q}%,aliases.ilike.%${q}%,latest_uniform.ilike.%${q}%`);
  if(type) query=query.eq('type',type);
  if(tier) query=query.ilike('highest_tier',`%${tier}%`);
  const {data,error}=await query.limit(275); if(error) return searchLocal(q,type,tier);
  if(!data?.length) return searchLocal(q,type,tier);
  return data.map((r:any)=>({id:r.id,name:r.name,aliases:r.aliases,type:r.type,gender:r.gender,allies:r.allies,image:r.image_url,latestUniform:r.latest_uniform,highestTier:r.highest_tier,attackType:r.attack_type,bestIso:r.best_iso,procRotation:r.proc_rotation,ctpRotation:r.ctp_rotation,metaCtpPve:r.meta_ctp_pve,offMetaCtpPve:r.off_meta_ctp_pve,metaCtpPvp:r.meta_ctp_pvp,offMetaCtpPvp:r.off_meta_ctp_pvp,needsArtifact:r.needs_artifact,artifactName:r.artifact_name,tierCategory:r.tier_category,tierRank:r.tier_rank,tierTags:r.tier_tags,t4:r.t4}));
}
export async function getCharacter(id:string):Promise<Character|null>{
  const db=serverSupabase();
  if(!db) return local.find(c=>c.id===id)||null;
  const {data:c,error}=await db.from('characters').select('*').eq('id',id).single(); if(error||!c) return local.find(x=>x.id===id)||null;
  const fallback=local.find(x=>x.id===id);
  const [{data:uniforms},{data:wbl},{data:shadowland},{data:dispatch},{data:story}]=await Promise.all([
    db.from('uniforms').select('uniform_id,uniform_name,is_latest,chronology_status').eq('character_id',id).order('is_latest',{ascending:false}),
    db.from('wbl_character_links').select('boss,stage_range,role').eq('character_id',id),
    db.from('shadowland_plus_links').select('stage,role').eq('character_id',id),
    db.from('dispatch_character_links').select('stage').eq('character_id',id),
    db.from('story_appearances').select('month,story_stage').eq('character_id',id).order('month',{ascending:false})
  ]);
  return {id:c.id,name:c.name,aliases:c.aliases,type:c.type,gender:c.gender,allies:c.allies,image:c.image_url,latestUniform:c.latest_uniform,highestTier:c.highest_tier,attackType:c.attack_type,bestIso:c.best_iso,procRotation:c.proc_rotation,ctpRotation:c.ctp_rotation,metaCtpPve:c.meta_ctp_pve,offMetaCtpPve:c.off_meta_ctp_pve,metaCtpPvp:c.meta_ctp_pvp,offMetaCtpPvp:c.off_meta_ctp_pvp,needsArtifact:c.needs_artifact,artifactName:c.artifact_name,tierCategory:c.tier_category,tierRank:c.tier_rank,tierTags:c.tier_tags,t4:c.t4,uniforms:uniforms?.length?uniforms:(fallback?.uniforms||[]),wbl:wbl?.length?wbl:(fallback?.wbl||[]),shadowland:shadowland?.length?shadowland:(fallback?.shadowland||[]),dispatch:dispatch?.length?dispatch:(fallback?.dispatch||[]),story:story?.length?story:(fallback?.story||[])};
}
