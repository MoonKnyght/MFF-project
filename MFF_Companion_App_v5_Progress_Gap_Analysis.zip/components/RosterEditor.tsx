'use client';
import {useEffect,useState} from 'react';
import type {Character} from '@/lib/types';
import {getRoster,removeRosterEntry,saveRosterEntry,type RosterEntry} from '@/lib/roster';

export default function RosterEditor({character,onChanged}:{character:Character;onChanged?:()=>void}){
 const [owned,setOwned]=useState(false),[tier,setTier]=useState(character.highestTier||''),[level,setLevel]=useState<number|string>(''),[uniformId,setUniformId]=useState(''),[ctp,setCtp]=useState(''),[artifact,setArtifact]=useState(false),[notes,setNotes]=useState(''),[msg,setMsg]=useState('');
 useEffect(()=>{setOwned(false);setTier(character.highestTier||'');setLevel('');setUniformId('');setCtp('');setArtifact(false);setNotes('');setMsg('');getRoster().then(rows=>{const r=rows.find(x=>x.character_id===character.id);if(!r)return;setOwned(true);setTier(r.tier||'');setLevel(r.level??'');setUniformId(r.uniform_id||'');setCtp(r.ctp||'');setArtifact(!!r.artifact_owned);setNotes(r.notes||'')})},[character.id,character.highestTier]);
 async function save(){setMsg('Saving…');const entry:RosterEntry={character_id:character.id,tier:tier||null,level:level===''?null:Number(level),uniform_id:uniformId||null,ctp:ctp||null,artifact_owned:artifact,notes:notes||null};await saveRosterEntry(entry);setOwned(true);setMsg('Saved');onChanged?.()}
 async function remove(){await removeRosterEntry(character.id);setOwned(false);setMsg('Removed');onChanged?.()}
 return <section className="rosterEditor"><div className="rosterEditorHead"><div><p className="eyebrow">MY ROSTER</p><h3>{owned?'Owned character':'Add this character'}</h3></div><span className={owned?'ownedBadge':'ownedBadge off'}>{owned?'OWNED':'NOT OWNED'}</span></div>
  <div className="formgrid"><label>Current tier<input value={tier} onChange={e=>setTier(e.target.value)} placeholder="T4, T3, Awakened…"/></label><label>Level<input type="number" min="1" max="100" value={level} onChange={e=>setLevel(e.target.value)}/></label>
  <label>Current uniform<select value={uniformId} onChange={e=>setUniformId(e.target.value)}><option value="">None / unknown</option>{character.uniforms?.map(u=><option value={u.uniform_id} key={u.uniform_id}>{u.uniform_name}{u.is_latest?' · latest':''}</option>)}</select></label>
  <label>Equipped CTP<input value={ctp} onChange={e=>setCtp(e.target.value)} placeholder={character.metaCtpPve||'Rage, Energy…'}/></label></div>
  <label className="check"><input type="checkbox" checked={artifact} onChange={e=>setArtifact(e.target.checked)}/> Own character artifact</label>
  <label>Notes<textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Build notes, team use, goals…"/></label>
  <div className="rosterActions"><button className="primary" onClick={save}>{owned?'Update roster':'Add to roster'}</button>{owned&&<button className="danger" onClick={remove}>Remove</button>}<small>{msg}</small></div>
 </section>
}
