import seed from '@/data/seed.characters.json';
import type {Character} from '@/lib/types';
import type {RosterEntry} from '@/lib/roster';
import {recommendationOptions,type RecommendMode} from '@/lib/recommend';

const chars=seed as Character[];

type Candidate={character:Character;roster?:RosterEntry;owned:boolean;sourceRole:string;baseScore:number;reasons:string[]};
export type TeamRequest={mode:RecommendMode;boss?:string;stage:string;roster?:RosterEntry[];rosterOnly?:boolean;limit?:number};
export type TeamSlot={character:Character;roster?:RosterEntry;role:'DPS'|'Lead'|'Support';score:number;reasons:string[]};
export type TeamSuggestion={id:string;score:number;dps:TeamSlot;lead:TeamSlot;support:TeamSlot;notes:string[]};

function tierWeight(category?:string|null){
  switch((category||'').toLowerCase()){
    case 'beyond meta': return 50;
    case 'high meta': return 42;
    case 'low meta': return 34;
    case 'useful': return 25;
    case 'lead/support meta': return 32;
    case 'lead/support useful': return 24;
    case 'useable': return 12;
    default:return 0;
  }
}
function ownedWeight(r?:RosterEntry){
  if(!r)return 0;
  let n=20;const t=String(r.tier||'').toUpperCase();
  if(t.includes('T4'))n+=18;else if(t.includes('T3'))n+=12;else if(t.includes('AWAK'))n+=9;
  if(r.uniform_id)n+=7;if(r.ctp)n+=6;if(r.artifact_owned)n+=3;return n;
}
function tags(c:Character){return String(c.tierTags||'').toLowerCase()}
function hasLeadership(c:Character){return tags(c).includes('leadership')}
function hasSupport(c:Character){return tags(c).includes('support')}
function modeScore(c:Character,mode:RecommendMode){
  if(mode==='wbl')return Number(c.t4?.wbl||0)*3;
  if(mode==='dispatch')return Number(c.t4?.farming||0)*3;
  return tierWeight(c.tierCategory)*.2;
}
function buildReadiness(c:Character,r?:RosterEntry){
  const out:string[]=[];
  if(r){if(r.tier)out.push(r.tier);if(r.uniform_id)out.push('owned uniform');if(r.ctp)out.push(r.ctp);if(r.artifact_owned)out.push('artifact owned')}
  else out.push('not on roster');
  if(!r?.ctp&&c.metaCtpPve&&c.metaCtpPve!=='-')out.push(`guide CTP: ${c.metaCtpPve}`);
  return out;
}
function stageLinks(c:Character,req:TeamRequest):string[]{
  if(req.mode==='wbl')return (c.wbl||[]).filter(x=>(!req.boss||x.boss===req.boss)&&String(x.stage_range)===req.stage).map(x=>x.role);
  if(req.mode==='shadowland')return (c.shadowland||[]).filter(x=>String(x.stage)===req.stage).map(x=>x.role||'recommended');
  return (c.dispatch||[]).filter(x=>String(x.stage)===req.stage).map(()=> 'recommended');
}
function candidates(req:TeamRequest):Candidate[]{
  const rosterMap=new Map((req.roster||[]).map(x=>[x.character_id,x]));
  const out:Candidate[]=[];
  for(const c of chars){
    const roles=stageLinks(c,req);if(!roles.length)continue;
    const r=rosterMap.get(c.id),owned=!!r;if(req.rosterOnly&&!owned)continue;
    const sourceRole=roles.includes('required')?'required':roles.includes('recommended')?'recommended':roles.includes('support')?'support':roles[0];
    const reasons=[`${sourceRole} in source guide`,...buildReadiness(c,r)];
    out.push({character:c,roster:r,owned,sourceRole,baseScore:tierWeight(c.tierCategory)+ownedWeight(r)+modeScore(c,req.mode),reasons});
  }
  return out;
}
function dpsScore(x:Candidate){
  let n=x.baseScore;
  if(x.sourceRole==='recommended')n+=50;if(x.sourceRole==='required')n+=46;if(x.sourceRole==='support')n-=20;
  if(hasSupport(x.character))n-=8;
  return n;
}
function leadScore(x:Candidate){
  let n=x.baseScore*.55;
  if(hasLeadership(x.character))n+=58;
  if(x.sourceRole==='support')n+=10;
  if(x.sourceRole==='required')n+=8;
  return n;
}
function supportScore(x:Candidate){
  let n=x.baseScore*.55;
  if(x.sourceRole==='support')n+=62;
  if(hasSupport(x.character))n+=42;
  if(hasLeadership(x.character))n+=6;
  return n;
}
function slot(x:Candidate,role:TeamSlot['role'],score:number):TeamSlot{
  const extra=role==='Lead'?(hasLeadership(x.character)?'leadership tagged':'best available stage-eligible lead'):
    role==='Support'?(x.sourceRole==='support'?'stage support':'support-tagged option'):'highest damage/readiness candidate';
  return {character:x.character,roster:x.roster,role,score,reasons:[...x.reasons,extra]};
}
export function teamBuilderOptions(){return recommendationOptions()}
export function buildTeams(req:TeamRequest):TeamSuggestion[]{
  const pool=candidates(req);if(pool.length<3)return [];
  const dps=[...pool].sort((a,b)=>dpsScore(b)-dpsScore(a)).slice(0,10);
  const leads=[...pool].sort((a,b)=>leadScore(b)-leadScore(a)).slice(0,12);
  const supports=[...pool].sort((a,b)=>supportScore(b)-supportScore(a)).slice(0,12);
  const teams:TeamSuggestion[]=[];const seen=new Set<string>();
  for(const d of dps)for(const l of leads)for(const s of supports){
    if(new Set([d.character.id,l.character.id,s.character.id]).size<3)continue;
    const ids=[d.character.id,l.character.id,s.character.id].sort().join('|');if(seen.has(ids))continue;seen.add(ids);
    const ds=dpsScore(d),ls=leadScore(l),ss=supportScore(s);
    const synergy=(hasLeadership(l.character)?12:0)+(s.sourceRole==='support'?14:hasSupport(s.character)?8:0)+(d.sourceRole==='required'?8:0);
    const notes:string[]=[];
    if(d.sourceRole==='required')notes.push(`${d.character.name} satisfies a required-character entry in the guide.`);
    if(hasLeadership(l.character))notes.push(`${l.character.name} is leadership-tagged in the source data.`);else notes.push('No dedicated leadership-tagged option was available in this combination; using the highest-scoring eligible leader slot.');
    if(s.sourceRole==='support')notes.push(`${s.character.name} is explicitly listed as a support for this stage.`);else if(hasSupport(s.character))notes.push(`${s.character.name} carries a support tag in the tier data.`);
    if(req.rosterOnly)notes.push('All three characters are from your saved roster.');
    teams.push({id:`${d.character.id}-${l.character.id}-${s.character.id}`,score:ds+ls+ss+synergy,dps:slot(d,'DPS',ds),lead:slot(l,'Lead',ls),support:slot(s,'Support',ss),notes});
  }
  return teams.sort((a,b)=>b.score-a.score).slice(0,req.limit||8);
}
