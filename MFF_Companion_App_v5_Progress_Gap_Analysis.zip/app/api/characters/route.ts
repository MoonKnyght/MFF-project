import { NextRequest, NextResponse } from 'next/server';
import { searchCharacters } from '@/lib/data';
export async function GET(req:NextRequest){
  const p=req.nextUrl.searchParams;
  try{return NextResponse.json(await searchCharacters(p.get('q')||'',p.get('type')||'',p.get('tier')||''));}
  catch(e){return NextResponse.json({error:String(e)},{status:500});}
}
