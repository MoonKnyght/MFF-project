create table if not exists public.characters (
 id text primary key, name text not null, aliases text, type text, gender text, allies text, image_url text,
 latest_uniform text, highest_tier text, attack_type text, best_iso text, proc_rotation text, ctp_rotation text,
 meta_ctp_pve text, off_meta_ctp_pve text, meta_ctp_pvp text, off_meta_ctp_pvp text, needs_artifact text,
 artifact_name text, tier_category text, tier_rank numeric, tier_tags text, t4 jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now()
);
create index if not exists characters_name_idx on public.characters using gin (to_tsvector('simple', coalesce(name,'')||' '||coalesce(aliases,'')||' '||coalesce(latest_uniform,'')));
create table if not exists public.uniforms (uniform_id text primary key, character_id text not null references public.characters(id) on delete cascade, uniform_name text not null, is_latest boolean not null default false, chronology_status text, release_date date, release_version text);
create index if not exists uniforms_character_idx on public.uniforms(character_id);
create table if not exists public.wbl_character_links (id bigint generated always as identity primary key, character_id text not null references public.characters(id) on delete cascade, boss text not null, stage_range text, role text not null);
create table if not exists public.shadowland_plus_links (id bigint generated always as identity primary key, character_id text not null references public.characters(id) on delete cascade, stage text not null, role text);
create table if not exists public.dispatch_character_links (id bigint generated always as identity primary key, character_id text not null references public.characters(id) on delete cascade, stage text not null);
create table if not exists public.story_appearances (id bigint generated always as identity primary key, character_id text not null references public.characters(id) on delete cascade, month text not null, story_stage text not null);
create table if not exists public.player_roster (
 user_id uuid not null references auth.users(id) on delete cascade,
 character_id text not null references public.characters(id) on delete cascade,
 tier text, level integer check(level is null or level between 1 and 100), uniform_id text references public.uniforms(uniform_id), notes text,
 updated_at timestamptz not null default now(), primary key(user_id,character_id)
);

-- Public game data: read-only for browser roles.
do $$ declare t text; begin foreach t in array array['characters','uniforms','wbl_character_links','shadowland_plus_links','dispatch_character_links','story_appearances'] loop execute format('alter table public.%I enable row level security',t); execute format('revoke all on table public.%I from anon, authenticated',t); execute format('grant select on table public.%I to anon, authenticated',t); execute format('drop policy if exists public_read on public.%I',t); execute format('create policy public_read on public.%I for select to anon, authenticated using (true)',t); end loop; end $$;

-- Private roster: signed-in players can only access their own rows.
alter table public.player_roster enable row level security;
revoke all on table public.player_roster from anon, authenticated;
grant select,insert,update,delete on table public.player_roster to authenticated;
create policy roster_select on public.player_roster for select to authenticated using ((select auth.uid())=user_id);
create policy roster_insert on public.player_roster for insert to authenticated with check ((select auth.uid())=user_id);
create policy roster_update on public.player_roster for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy roster_delete on public.player_roster for delete to authenticated using ((select auth.uid())=user_id);
