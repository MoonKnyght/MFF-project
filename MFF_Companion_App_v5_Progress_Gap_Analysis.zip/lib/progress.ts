'use client';
import {browserSupabase} from '@/lib/supabase';
import type {TeamSuggestion} from '@/lib/team-builder';

export type SavedTeam={id:string;name?:string|null;mode:'wbl'|'shadowland'|'dispatch';boss?:string|null;stage:string;score?:number|null;team:TeamSuggestion;created_at:string};
export type StageClear={id:string;mode:'wbl'|'shadowland'|'dispatch';boss?:string|null;stage:string;saved_team_id?:string|null;cleared_at:string};
const TEAM_KEY='mff-companion-saved-teams-v1',CLEAR_KEY='mff-companion-stage-clears-v1';
const read=<T,>(key:string):T[]=>{try{return JSON.parse(localStorage.getItem(key)||'[]')}catch{return []}};
const write=(key:string,v:unknown)=>{localStorage.setItem(key,JSON.stringify(v));window.dispatchEvent(new Event('mff-progress-changed'))};
const uid=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`;

export async function getSavedTeams():Promise<SavedTeam[]>{
 const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {data,error}=await db.from('saved_teams').select('id,name,mode,boss,stage,score,team,created_at').order('created_at',{ascending:false});if(!error)return (data||[]) as SavedTeam[]}}
 return read<SavedTeam>(TEAM_KEY);
}
export async function saveTeam(input:{name?:string;mode:SavedTeam['mode'];boss?:string;stage:string;team:TeamSuggestion}){
 const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {data,error}=await db.from('saved_teams').insert({user_id:user.id,name:input.name||null,mode:input.mode,boss:input.boss||null,stage:input.stage,score:input.team.score,team:input.team}).select('id,name,mode,boss,stage,score,team,created_at').single();if(error)throw error;window.dispatchEvent(new Event('mff-progress-changed'));return data as SavedTeam}}
 const row:SavedTeam={id:uid(),name:input.name||null,mode:input.mode,boss:input.boss||null,stage:input.stage,score:input.team.score,team:input.team,created_at:new Date().toISOString()};write(TEAM_KEY,[row,...read<SavedTeam>(TEAM_KEY)]);return row;
}
export async function deleteSavedTeam(id:string){const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {error}=await db.from('saved_teams').delete().eq('id',id);if(error)throw error;window.dispatchEvent(new Event('mff-progress-changed'));return}}write(TEAM_KEY,read<SavedTeam>(TEAM_KEY).filter(x=>x.id!==id))}
export async function getStageClears():Promise<StageClear[]>{const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {data,error}=await db.from('stage_clears').select('id,mode,boss,stage,saved_team_id,cleared_at').order('cleared_at',{ascending:false});if(!error)return (data||[]) as StageClear[]}}return read<StageClear>(CLEAR_KEY)}
export async function markStageClear(input:{mode:StageClear['mode'];boss?:string;stage:string;saved_team_id?:string}){const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {data,error}=await db.from('stage_clears').upsert({user_id:user.id,mode:input.mode,boss:input.boss||'',stage:input.stage,saved_team_id:input.saved_team_id||null,cleared_at:new Date().toISOString()},{onConflict:'user_id,mode,boss,stage'}).select().single();if(error)throw error;window.dispatchEvent(new Event('mff-progress-changed'));return data as StageClear}}
 const rows=read<StageClear>(CLEAR_KEY);const key=(x:StageClear)=>`${x.mode}|${x.boss||''}|${x.stage}`,target=`${input.mode}|${input.boss||''}|${input.stage}`;const row:StageClear={id:uid(),mode:input.mode,boss:input.boss||'',stage:input.stage,saved_team_id:input.saved_team_id||null,cleared_at:new Date().toISOString()};write(CLEAR_KEY,[row,...rows.filter(x=>key(x)!==target)]);return row}
export async function removeStageClear(id:string){const db=browserSupabase();if(db){const {data:{user}}=await db.auth.getUser();if(user){const {error}=await db.from('stage_clears').delete().eq('id',id);if(error)throw error;window.dispatchEvent(new Event('mff-progress-changed'));return}}write(CLEAR_KEY,read<StageClear>(CLEAR_KEY).filter(x=>x.id!==id))}
