import { createClient } from '@supabase/supabase-js';
export function browserSupabase() {
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  if(!url||!key) return null;
  return createClient(url,key);
}
export function serverSupabase() { return browserSupabase(); }
