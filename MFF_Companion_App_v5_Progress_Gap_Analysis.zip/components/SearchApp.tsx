'use client';
import {useEffect,useMemo,useState} from 'react';
import type {Character} from '@/lib/types';
import RosterEditor from '@/components/RosterEditor';
import {getRoster} from '@/lib/roster';
const types=['','combat','blast','speed','universal'];
export default function SearchApp(){
 const [q,setQ]=useState(''),[type,setType]=useState(''),[tier,setTier]=useState(''),[items,setItems]=useState<Character[]>([]),[selected,setSelected]=useState<Character|null>(null),[loading,setLoading]=useState(true),[rosterOnly,setRosterOnly]=useState(false),[rosterIds,setRosterIds]=useState<Set<string>>(new Set());
 useEffect(()=>{const refresh=()=>getRoster().then(r=>setRosterIds(new Set(r.map(x=>x.character_id))));refresh();window.addEventListener('mff-roster-changed',refresh);return()=>window.removeEventListener('mff-roster-changed',refresh)},[]);
 useEffect(()=>{const t=setTimeout(async()=>{setLoading(true);const p=new URLSearchParams({q,type,tier});const r=await fetch('/api/characters?'+p);setItems(await r.json());setLoading(false)},120);return()=>clearTimeout(t)},[q,type,tier]);
 async function open(id:string){const r=await fetch('/api/characters/'+id);setSelected(await r.json())}
 const visible=useMemo(()=>rosterOnly?items.filter(c=>rosterIds.has(c.id)):items,[items,rosterOnly,rosterIds]);
 const count=visible.length;
 return <>
  <section className="hero"><p className="eyebrow">MARVEL FUTURE FIGHT COMPANION</p><h1>Find the answer. Build the character.</h1><p>Search characters, uniforms, CTP recommendations, rotations, rankings and game-mode usage.</p>
   <input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search Magneto, Rage, uniform…" />
   <div className="filters">{types.map(x=><button key={x||'all'} className={type===x?'active':''} onClick={()=>setType(x)}>{x||'all'}</button>)}<select value={tier} onChange={e=>setTier(e.target.value)}><option value="">Any advancement</option><option>T4</option><option>T3</option><option>Awakened</option><option>Lvl 70</option></select><button className={rosterOnly?'active':''} onClick={()=>setRosterOnly(!rosterOnly)}>My roster</button></div>
  </section>
  <div className="resultbar"><b>{loading?'…':count}</b> characters</div>
  <section className="grid">{visible.map(c=><button className="card" key={c.id} onClick={()=>open(c.id)}><img src={c.image||''} alt=""/><span><b>{c.name}</b><small>{c.highestTier||'—'} · {c.type||'—'}</small><em>{c.latestUniform||'No uniform listed'}</em></span></button>)}</section>
  {selected&&<div className="overlay" onClick={()=>setSelected(null)}><article className="drawer" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}>×</button><header className="profile"><img src={selected.image||''} alt=""/><div><p className="eyebrow">{selected.type} · {selected.attackType}</p><h2>{selected.name}</h2><p>{selected.highestTier} · {selected.tierCategory||'Unranked'}</p></div></header>
   <div className="statgrid"><Stat k="Latest uniform" v={selected.latestUniform}/><Stat k="PvE CTP" v={selected.metaCtpPve}/><Stat k="PvP CTP" v={selected.metaCtpPvp}/><Stat k="ISO-8" v={selected.bestIso}/><Stat k="Artifact" v={selected.artifactName||selected.needsArtifact}/><Stat k="Rotation" v={selected.procRotation}/></div>
   <RosterEditor character={selected}/><h3>Uniforms</h3><div className="chips">{selected.uniforms?.map(u=><span key={u.uniform_id} className={u.is_latest?'latest':''}>{u.uniform_name}{u.is_latest?' · latest':''}</span>)}</div>
   <h3>T4 performance</h3><div className="scoregrid">{Object.entries(selected.t4||{}).map(([k,v])=><Stat key={k} k={k.toUpperCase()} v={v??'—'}/>)}</div>
   <h3>Game modes</h3><Game title="World Boss" rows={selected.wbl?.map(x=>`${x.boss} ${x.stage_range} · ${x.role}`)}/><Game title="Shadowland+" rows={selected.shadowland?.map(x=>`Stage ${x.stage} · ${x.role}`)}/><Game title="Dispatch" rows={selected.dispatch?.map(x=>`Stage ${x.stage}`)}/><Game title="Story" rows={selected.story?.slice(0,18).map(x=>`${x.month} · ${x.story_stage}`)}/>
  </article></div>}
 </>
}
function Stat({k,v}:{k:string,v:any}){return <div className="stat"><small>{k}</small><b>{v||'—'}</b></div>}
function Game({title,rows}:{title:string,rows?:string[]}){return <div className="game"><b>{title}</b><p>{rows?.length?rows.join(' • '):'No linked recommendations in the source data.'}</p></div>}
