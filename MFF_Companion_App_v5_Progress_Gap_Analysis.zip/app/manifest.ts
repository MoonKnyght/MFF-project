import type { MetadataRoute } from 'next';
export default function manifest():MetadataRoute.Manifest{return {name:'MFF Companion',short_name:'MFF',description:'Marvel Future Fight player database and roster companion',start_url:'/',display:'standalone',background_color:'#07111f',theme_color:'#07111f',icons:[{src:'/icon.svg',sizes:'any',type:'image/svg+xml'}]}}
