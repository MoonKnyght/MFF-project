import SearchApp from '@/components/SearchApp';
export default function Page(){return <main><SearchApp/></main>}
