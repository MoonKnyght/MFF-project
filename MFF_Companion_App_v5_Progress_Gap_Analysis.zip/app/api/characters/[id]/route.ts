import { NextResponse } from 'next/server';
import { getCharacter } from '@/lib/data';
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){
  const {id}=await params; const c=await getCharacter(id);
  return c?NextResponse.json(c):NextResponse.json({error:'Not found'},{status:404});
}
