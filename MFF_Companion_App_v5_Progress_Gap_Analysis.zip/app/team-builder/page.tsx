'use client';
import {useEffect,useState} from 'react';
import {getRoster,type RosterEntry} from '@/lib/roster';
import type {Character} from '@/lib/types';
import {markStageClear,saveTeam} from '@/lib/progress';

type Mode='wbl'|'shadowland'|'dispatch';
type Options={bosses:string[];wblStages:string[];shadowStages:string[];dispatchStages:string[]};
type Slot={character:Character;roster?:RosterEntry;role:'DPS'|'Lead'|'Support';score:number;reasons:string[]};
type Team={id:string;score:number;dps:Slot;lead:Slot;support:Slot;notes:string[]};

export default function TeamBuilderPage(){
 const [mode,setMode]=useState<Mode>('wbl'),[boss,setBoss]=useState('Knull'),[stage,setStage]=useState(''),[ownedOnly,setOwnedOnly]=useState(true),[opts,setOpts]=useState<Options|null>(null),[roster,setRoster]=useState<RosterEntry[]>([]),[teams,setTeams]=useState<Team[]>([]),[loading,setLoading]=useState(false);
 useEffect(()=>{fetch('/api/team-builder').then(r=>r.json()).then(setOpts);getRoster().then(setRoster)},[]);
 useEffect(()=>{if(!opts)return;setStage(mode==='wbl'?(opts.wblStages[0]||''):mode==='shadowland'?(opts.shadowStages[0]||''):(opts.dispatchStages[0]||''))},[mode,opts]);
 useEffect(()=>{if(opts&&mode==='wbl'&&!opts.bosses.includes(boss))setBoss(opts.bosses[0]||'')},[opts,mode,boss]);
 async function run(){if(!stage)return;setLoading(true);const r=await fetch('/api/team-builder',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode,boss:mode==='wbl'?boss:undefined,stage,roster,rosterOnly:ownedOnly,limit:8})});const json=await r.json();setTeams(Array.isArray(json)?json:[]);setLoading(false)}
 useEffect(()=>{if(opts&&stage)run()},[mode,boss,stage,ownedOnly,opts,roster.length]);
 return <main className="teamPage"><section className="teamHero"><p className="eyebrow">ROSTER-AWARE TEAM BUILDER</p><h1>Build me a team.</h1><p>Select a stage and the app will assemble ranked three-character teams using guide eligibility, player ownership, build readiness, leadership tags, support roles, and mode performance.</p></section>
 <section className="recommendControls"><div className="modeTabs">{(['wbl','shadowland','dispatch'] as Mode[]).map(x=><button className={mode===x?'active':''} key={x} onClick={()=>setMode(x)}>{x==='wbl'?'World Boss':x==='shadowland'?'Shadowland+':'Dispatch'}</button>)}</div><div className="recommendFilters">{mode==='wbl'&&<label>Boss<select value={boss} onChange={e=>setBoss(e.target.value)}>{opts?.bosses.map(x=><option key={x}>{x}</option>)}</select></label>}<label>Stage<select value={stage} onChange={e=>setStage(e.target.value)}>{(mode==='wbl'?opts?.wblStages:mode==='shadowland'?opts?.shadowStages:opts?.dispatchStages)?.map(x=><option key={x}>{x}</option>)}</select></label><label className="checkToggle"><input type="checkbox" checked={ownedOnly} onChange={e=>setOwnedOnly(e.target.checked)}/> My roster only</label><button className="primary" onClick={run}>Build teams</button></div></section>
 <section className="recommendSummary"><b>{loading?'…':teams.length}</b><span>team suggestions</span>{ownedOnly&&!roster.length&&<em>Your roster is empty — add characters before using roster-only teams.</em>}</section>
 {!loading&&!teams.length&&<section className="empty"><h2>No complete team found</h2><p>There may be fewer than three matching characters in your roster/source data for this stage. Turn off “My roster only” to see global team ideas.</p></section>}
 <section className="teamList">{teams.map((t,i)=><TeamCard key={t.id} team={t} rank={i+1} mode={mode} boss={boss} stage={stage}/>)}</section></main>
}
function TeamCard({team,rank,mode,boss,stage}:{team:Team;rank:number;mode:Mode;boss?:string;stage:string}){
 const [status,setStatus]=useState('');
 async function save(cleared=false){try{setStatus('Saving…');const row=await saveTeam({mode,boss:mode==='wbl'?boss:undefined,stage,team:team as any});if(cleared)await markStageClear({mode,boss:mode==='wbl'?boss:undefined,stage,saved_team_id:row.id});setStatus(cleared?'Saved + clear tracked':'Team saved')}catch(e){setStatus(e instanceof Error?e.message:'Could not save')}}
 return <article className="teamCard"><header><div><span className="teamRank">#{rank}</span><b>Recommended team</b></div><div className="teamScore"><small>TEAM MATCH</small><strong>{Math.round(team.score)}</strong></div></header><div className="teamSlots"><SlotCard slot={team.dps}/><SlotCard slot={team.lead}/><SlotCard slot={team.support}/></div><div className="teamNotes">{team.notes.map(n=><p key={n}>• {n}</p>)}</div><div className="teamActions"><button onClick={()=>save(false)}>Save team</button><button className="primary" onClick={()=>save(true)}>Save + mark cleared</button>{status&&<small>{status}</small>}</div></article>}
function SlotCard({slot}:{slot:Slot}){return <div className={`teamSlot ${slot.role.toLowerCase()}`}><span className="rolePill">{slot.role}</span><img src={slot.character.image||''} alt=""/><div><b>{slot.character.name}</b><small>{slot.roster?.tier||slot.character.highestTier||'—'} · {slot.character.latestUniform||'No uniform listed'}</small><p>{slot.roster?.ctp||slot.character.metaCtpPve||'No CTP recorded'}</p><div className="readiness">{slot.reasons.slice(0,4).map(x=><span key={x}>{x}</span>)}</div></div></div>}
