'use client';
import {browserSupabase} from '@/lib/supabase';

export type RosterEntry={
  character_id:string;
  tier?:string|null;
  level?:number|null;
  uniform_id?:string|null;
  ctp?:string|null;
  artifact_owned?:boolean;
  notes?:string|null;
};
const KEY='mff-companion-roster-v1';
function readLocal():RosterEntry[]{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}}
function writeLocal(rows:RosterEntry[]){localStorage.setItem(KEY,JSON.stringify(rows));window.dispatchEvent(new Event('mff-roster-changed'))}
export async function getRoster():Promise<RosterEntry[]>{
  const db=browserSupabase();
  if(db){
    const {data:{user}}=await db.auth.getUser();
    if(user){const {data,error}=await db.from('player_roster').select('character_id,tier,level,uniform_id,ctp,artifact_owned,notes').order('updated_at',{ascending:false});if(!error)return data||[]}
  }
  return readLocal();
}
export async function saveRosterEntry(entry:RosterEntry){
  const db=browserSupabase();
  if(db){
    const {data:{user}}=await db.auth.getUser();
    if(user){const {error}=await db.from('player_roster').upsert({...entry,user_id:user.id,updated_at:new Date().toISOString()},{onConflict:'user_id,character_id'});if(error)throw error;window.dispatchEvent(new Event('mff-roster-changed'));return}
  }
  const rows=readLocal();const i=rows.findIndex(x=>x.character_id===entry.character_id);if(i>=0)rows[i]={...rows[i],...entry};else rows.unshift(entry);writeLocal(rows)
}
export async function removeRosterEntry(character_id:string){
  const db=browserSupabase();
  if(db){const {data:{user}}=await db.auth.getUser();if(user){const {error}=await db.from('player_roster').delete().eq('character_id',character_id);if(error)throw error;window.dispatchEvent(new Event('mff-roster-changed'));return}}
  writeLocal(readLocal().filter(x=>x.character_id!==character_id))
}
export async function isCloudRoster(){const db=browserSupabase();if(!db)return false;const {data:{user}}=await db.auth.getUser();return !!user}
