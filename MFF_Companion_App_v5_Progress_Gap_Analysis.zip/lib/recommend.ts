import seed from '@/data/seed.characters.json';
import type {Character} from '@/lib/types';
import type {RosterEntry} from '@/lib/roster';

const chars=seed as Character[];
const byId=new Map(chars.map(c=>[c.id,c]));

export type RecommendMode='wbl'|'shadowland'|'dispatch';
export type RecommendRequest={
  mode:RecommendMode;
  boss?:string;
  stage?:string;
  roster?:RosterEntry[];
  rosterOnly?:boolean;
};
export type Recommendation={
  character:Character;
  owned:boolean;
  role:string;
  stage:string;
  score:number;
  readiness:string[];
  roster?:RosterEntry;
};

function tierWeight(category?:string|null){
  switch((category||'').toLowerCase()){
    case 'beyond meta': return 50;
    case 'high meta': return 42;
    case 'low meta': return 34;
    case 'useful': return 25;
    case 'lead/support meta': return 30;
    case 'lead/support useful': return 22;
    case 'useable': return 12;
    default:return 0;
  }
}
function roleWeight(role:string){return role==='recommended'?40:role==='required'?36:role==='support'?28:18}
function rosterWeight(r?:RosterEntry){
  if(!r)return 0;
  let s=25;
  const tier=String(r.tier||'').toUpperCase();
  if(tier.includes('T4'))s+=18; else if(tier.includes('T3'))s+=12; else if(tier.includes('AWAK'))s+=9;
  if(r.uniform_id)s+=8;
  if(r.ctp)s+=6;
  if(r.artifact_owned)s+=4;
  return s;
}
function readiness(c:Character,r?:RosterEntry){
  if(!r)return ['Not on your roster'];
  const out:string[]=[];
  if(r.tier)out.push(r.tier);
  if(r.level)out.push(`Lv. ${r.level}`);
  if(r.uniform_id)out.push('Uniform set'); else if(c.latestUniform)out.push('Uniform not marked');
  if(r.ctp)out.push(r.ctp); else if(c.metaCtpPve&&c.metaCtpPve!=='-')out.push(`Suggested CTP: ${c.metaCtpPve}`);
  if(r.artifact_owned)out.push('Artifact owned'); else if(c.needsArtifact&&![null,'','-','N','Optional'].includes(c.needsArtifact))out.push('Artifact may matter');
  return out;
}

export function recommendationOptions(){
  const bosses=new Set<string>(); const wblStages=new Set<string>(); const shadowStages=new Set<string>(); const dispatchStages=new Set<string>();
  for(const c of chars){
    for(const x of c.wbl||[]){bosses.add(x.boss);wblStages.add(String(x.stage_range))}
    for(const x of c.shadowland||[])shadowStages.add(String(x.stage));
    for(const x of c.dispatch||[])dispatchStages.add(String(x.stage));
  }
  const numeric=(a:string,b:string)=>Number(a.split('-')[0])-Number(b.split('-')[0]);
  return {bosses:[...bosses].sort(),wblStages:[...wblStages].sort(numeric),shadowStages:[...shadowStages].sort((a,b)=>Number(a)-Number(b)),dispatchStages:[...dispatchStages].sort(numeric)};
}

export function recommend(req:RecommendRequest):Recommendation[]{
  const rosterMap=new Map((req.roster||[]).map(r=>[r.character_id,r]));
  const rows:Recommendation[]=[];
  for(const c of chars){
    const owned=rosterMap.has(c.id); if(req.rosterOnly&&!owned)continue;
    if(req.mode==='wbl'){
      for(const x of c.wbl||[]){
        if(req.boss&&x.boss!==req.boss)continue;
        if(req.stage&&String(x.stage_range)!==req.stage)continue;
        const r=rosterMap.get(c.id);
        const t4=Number(c.t4?.wbl||0);
        rows.push({character:c,owned,role:x.role,stage:`${x.boss} ${x.stage_range}`,score:roleWeight(x.role)+tierWeight(c.tierCategory)+rosterWeight(r)+t4*2,readiness:readiness(c,r),roster:r});
      }
    } else if(req.mode==='shadowland'){
      for(const x of c.shadowland||[]){
        if(req.stage&&String(x.stage)!==req.stage)continue;
        const r=rosterMap.get(c.id);
        rows.push({character:c,owned,role:x.role||'recommended',stage:`Stage ${x.stage}`,score:roleWeight(x.role||'recommended')+tierWeight(c.tierCategory)+rosterWeight(r),readiness:readiness(c,r),roster:r});
      }
    } else if(req.mode==='dispatch'){
      for(const x of c.dispatch||[]){
        if(req.stage&&String(x.stage)!==req.stage)continue;
        const r=rosterMap.get(c.id);
        rows.push({character:c,owned,role:'recommended',stage:`Stage ${x.stage}`,score:35+tierWeight(c.tierCategory)+rosterWeight(r)+(Number(c.t4?.farming||0)*2),readiness:readiness(c,r),roster:r});
      }
    }
  }
  return rows.sort((a,b)=>b.score-a.score||a.character.name.localeCompare(b.character.name));
}
