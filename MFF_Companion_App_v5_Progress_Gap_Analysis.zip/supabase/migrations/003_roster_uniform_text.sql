-- Keep roster uniform selections usable before the full uniform catalog is seeded.
-- character_id remains FK-protected; uniform_id is intentionally stored as a stable text ID.
alter table public.player_roster drop constraint if exists player_roster_uniform_id_fkey;
