import seed from '@/data/seed.characters.json';
import type {Character} from '@/lib/types';
import type {RosterEntry} from '@/lib/roster';
import type {StageClear} from '@/lib/progress';

const chars=seed as Character[];
export type GapStage={mode:'wbl'|'shadowland'|'dispatch';boss?:string;stage:string};
export type GapResult={character:Character;unlockCount:number;stages:GapStage[];reason:string};
const key=(s:GapStage)=>`${s.mode}|${s.boss||''}|${s.stage}`;

export function analyzeRosterGaps(roster:RosterEntry[],clears:StageClear[]=[]):GapResult[]{
 const owned=new Set(roster.map(r=>r.character_id));const cleared=new Set(clears.map(c=>key({mode:c.mode,boss:c.boss||undefined,stage:c.stage})));
 const stageMap=new Map<string,{stage:GapStage;ids:Set<string>}>();
 for(const c of chars){
  for(const x of c.wbl||[]){const stage={mode:'wbl' as const,boss:x.boss,stage:String(x.stage_range)};if(cleared.has(key(stage)))continue;const k=key(stage);if(!stageMap.has(k))stageMap.set(k,{stage,ids:new Set});stageMap.get(k)!.ids.add(c.id)}
  for(const x of c.shadowland||[]){const stage={mode:'shadowland' as const,stage:String(x.stage)};if(cleared.has(key(stage)))continue;const k=key(stage);if(!stageMap.has(k))stageMap.set(k,{stage,ids:new Set});stageMap.get(k)!.ids.add(c.id)}
  for(const x of c.dispatch||[]){const stage={mode:'dispatch' as const,stage:String(x.stage)};if(cleared.has(key(stage)))continue;const k=key(stage);if(!stageMap.has(k))stageMap.set(k,{stage,ids:new Set});stageMap.get(k)!.ids.add(c.id)}
 }
 const unlocks=new Map<string,GapStage[]>();
 for(const {stage,ids} of stageMap.values()){
  const ownedEligible=[...ids].filter(id=>owned.has(id));
  if(ownedEligible.length>=3)continue;
  // A single investment can only create a complete 3-character eligible pool when the player already owns at least two.
  if(ownedEligible.length!==2)continue;
  for(const id of ids){if(owned.has(id))continue;const list=unlocks.get(id)||[];list.push(stage);unlocks.set(id,list)}
 }
 return [...unlocks.entries()].map(([id,stages])=>({character:chars.find(c=>c.id===id)!,unlockCount:stages.length,stages,reason:`You already own at least 2 stage-eligible characters for ${stages.length} uncleared stage${stages.length===1?'':'s'}.`})).filter(x=>x.character).sort((a,b)=>b.unlockCount-a.unlockCount||String(a.character.name).localeCompare(String(b.character.name))).slice(0,20);
}
