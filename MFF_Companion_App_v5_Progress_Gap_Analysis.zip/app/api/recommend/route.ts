import {NextResponse} from 'next/server';
import {recommend,recommendationOptions} from '@/lib/recommend';
export async function GET(){return NextResponse.json(recommendationOptions())}
export async function POST(req:Request){try{return NextResponse.json(recommend(await req.json()))}catch(e){return NextResponse.json({error:String(e)},{status:400})}}
