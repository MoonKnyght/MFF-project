import './styles.css';
import PwaRegister from '@/components/PwaRegister';
export const metadata={title:'MFF Companion',description:'Player-friendly Marvel Future Fight database and roster companion',manifest:'/manifest.webmanifest'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><nav><a href="/" className="brand">MFF Companion</a><div><a href="/">Database</a><a href="/recommend">Recommendations</a><a href="/team-builder">Team Builder</a><a href="/progress">Progress</a><a href="/roster">My Roster</a><a href="/login">Sign in</a></div></nav>{children}<PwaRegister/></body></html>}
