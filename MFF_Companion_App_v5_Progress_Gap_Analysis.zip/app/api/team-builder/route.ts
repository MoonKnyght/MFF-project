import {NextResponse} from 'next/server';
import {buildTeams,teamBuilderOptions} from '@/lib/team-builder';
export async function GET(){return NextResponse.json(teamBuilderOptions())}
export async function POST(req:Request){try{return NextResponse.json(buildTeams(await req.json()))}catch(e){return NextResponse.json({error:String(e)},{status:400})}}
