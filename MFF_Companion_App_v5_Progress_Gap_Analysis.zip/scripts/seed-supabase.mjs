import {createClient} from '@supabase/supabase-js';import fs from 'node:fs';
const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SECRET_KEY;if(!url||!key)throw new Error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SECRET_KEY');
const db=createClient(url,key,{auth:{persistSession:false}});const chars=JSON.parse(fs.readFileSync(new URL('../data/seed.characters.json',import.meta.url),'utf8'));
const clean=v=>Number.isNaN(v)?null:v;
const characterRows=chars.map(c=>({id:c.id,name:c.name,aliases:c.aliases,type:c.type,gender:c.gender,allies:c.allies,image_url:c.image,latest_uniform:c.latestUniform,highest_tier:c.highestTier,attack_type:c.attackType,best_iso:c.bestIso,proc_rotation:c.procRotation,ctp_rotation:c.ctpRotation,meta_ctp_pve:c.metaCtpPve,off_meta_ctp_pve:c.offMetaCtpPve,meta_ctp_pvp:c.metaCtpPvp,off_meta_ctp_pvp:c.offMetaCtpPvp,needs_artifact:c.needsArtifact,artifact_name:c.artifactName,tier_category:c.tierCategory,tier_rank:clean(c.tierRank),tier_tags:c.tierTags,t4:c.t4||{}}));
async function upsert(table,rows,key){for(let i=0;i<rows.length;i+=250){const {error}=await db.from(table).upsert(rows.slice(i,i+250),{onConflict:key});if(error)throw error;}}
await upsert('characters',characterRows,'id');
await upsert('uniforms',chars.flatMap(c=>(c.uniforms||[]).map(u=>({uniform_id:u.uniform_id,character_id:c.id,uniform_name:u.uniform_name,is_latest:!!u.is_latest,chronology_status:u.chronology_status}))), 'uniform_id');
for(const table of ['wbl_character_links','shadowland_plus_links','dispatch_character_links','story_appearances']) await db.from(table).delete().neq('id',0);
const insertChunk=async(table,rows)=>{for(let i=0;i<rows.length;i+=250){const {error}=await db.from(table).insert(rows.slice(i,i+250));if(error)throw error;}};
await insertChunk('wbl_character_links',chars.flatMap(c=>(c.wbl||[]).map(x=>({character_id:c.id,boss:x.boss,stage_range:x.stage_range,role:x.role}))));
await insertChunk('shadowland_plus_links',chars.flatMap(c=>(c.shadowland||[]).map(x=>({character_id:c.id,stage:String(x.stage),role:x.role||null}))));
await insertChunk('dispatch_character_links',chars.flatMap(c=>(c.dispatch||[]).map(x=>({character_id:c.id,stage:String(x.stage)}))));
await insertChunk('story_appearances',chars.flatMap(c=>(c.story||[]).map(x=>({character_id:c.id,month:x.month,story_stage:x.story_stage}))));
console.log(`Seeded ${chars.length} characters.`);
