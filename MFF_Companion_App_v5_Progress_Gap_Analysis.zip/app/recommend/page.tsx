'use client';
import {useEffect,useMemo,useState} from 'react';
import {getRoster,type RosterEntry} from '@/lib/roster';
import type {Character} from '@/lib/types';

type Mode='wbl'|'shadowland'|'dispatch';
type Options={bosses:string[];wblStages:string[];shadowStages:string[];dispatchStages:string[]};
type Rec={character:Character;owned:boolean;role:string;stage:string;score:number;readiness:string[];roster?:RosterEntry};
export default function RecommendPage(){
 const [mode,setMode]=useState<Mode>('wbl'),[boss,setBoss]=useState('Knull'),[stage,setStage]=useState(''),[ownedOnly,setOwnedOnly]=useState(true),[opts,setOpts]=useState<Options|null>(null),[rows,setRows]=useState<Rec[]>([]),[loading,setLoading]=useState(false),[roster,setRoster]=useState<RosterEntry[]>([]);
 useEffect(()=>{fetch('/api/recommend').then(r=>r.json()).then(setOpts);getRoster().then(setRoster)},[]);
 useEffect(()=>{if(!opts)return;setStage(mode==='wbl'?(opts.wblStages[0]||''):mode==='shadowland'?(opts.shadowStages[0]||''):(opts.dispatchStages[0]||''))},[mode,opts]);
 useEffect(()=>{if(opts&&mode==='wbl'&&!opts.bosses.includes(boss))setBoss(opts.bosses[0]||'')},[opts,mode,boss]);
 async function run(){setLoading(true);const r=await fetch('/api/recommend',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode,boss:mode==='wbl'?boss:undefined,stage,roster,rosterOnly:ownedOnly})});setRows(await r.json());setLoading(false)}
 useEffect(()=>{if(opts&&stage)run()},[mode,boss,stage,ownedOnly,opts,roster.length]);
 const groups=useMemo(()=>({required:rows.filter(r=>r.role==='required'),recommended:rows.filter(r=>r.role==='recommended'),support:rows.filter(r=>r.role==='support'),other:rows.filter(r=>!['required','recommended','support'].includes(r.role))}),[rows]);
 return <main className="recommendPage"><section className="recommendHero"><p className="eyebrow">ROSTER-AWARE RECOMMENDATIONS</p><h1>Who can I use?</h1><p>Choose a game mode and stage. Results are ranked using the guide data plus the characters and builds you marked in <b>My Roster</b>.</p></section>
 <section className="recommendControls"><div className="modeTabs">{(['wbl','shadowland','dispatch'] as Mode[]).map(x=><button className={mode===x?'active':''} key={x} onClick={()=>setMode(x)}>{x==='wbl'?'World Boss':x==='shadowland'?'Shadowland+':'Dispatch'}</button>)}</div>
  <div className="recommendFilters">{mode==='wbl'&&<label>Boss<select value={boss} onChange={e=>setBoss(e.target.value)}>{opts?.bosses.map(x=><option key={x}>{x}</option>)}</select></label>}<label>Stage<select value={stage} onChange={e=>setStage(e.target.value)}>{(mode==='wbl'?opts?.wblStages:mode==='shadowland'?opts?.shadowStages:opts?.dispatchStages)?.map(x=><option key={x}>{x}</option>)}</select></label><label className="checkToggle"><input type="checkbox" checked={ownedOnly} onChange={e=>setOwnedOnly(e.target.checked)}/> My roster only</label><button className="primary" onClick={run}>Refresh</button></div>
 </section>
 <section className="recommendSummary"><b>{loading?'…':rows.length}</b><span>{ownedOnly?'usable roster matches':'guide matches'}</span>{ownedOnly&&!roster.length&&<em>Your roster is empty — add characters first.</em>}</section>
 <RecGroup title="Required" rows={groups.required}/><RecGroup title="Recommended" rows={groups.recommended}/><RecGroup title="Supports" rows={groups.support}/><RecGroup title="Other" rows={groups.other}/>
 </main>
}
function RecGroup({title,rows}:{title:string;rows:Rec[]}){if(!rows.length)return null;return <section className="recGroup"><h2>{title}</h2><div className="recGrid">{rows.map((r,i)=><article className="recCard" key={`${r.character.id}-${r.stage}-${r.role}`}><div className="rank">#{i+1}</div><img src={r.character.image||''} alt=""/><div className="recInfo"><div className="recTitle"><b>{r.character.name}</b><span className={r.owned?'ownedPill':'ownedPill off'}>{r.owned?'OWNED':'NOT OWNED'}</span></div><small>{r.stage} · {r.role}</small><p>{r.character.latestUniform||'No uniform listed'}</p><div className="readiness">{r.readiness.map(x=><span key={x}>{x}</span>)}</div></div><div className="score"><small>match</small><b>{Math.round(r.score)}</b></div></article>)}</div></section>}
