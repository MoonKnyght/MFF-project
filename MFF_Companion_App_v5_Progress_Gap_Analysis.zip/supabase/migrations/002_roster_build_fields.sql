alter table public.player_roster add column if not exists ctp text;
alter table public.player_roster add column if not exists artifact_owned boolean not null default false;
