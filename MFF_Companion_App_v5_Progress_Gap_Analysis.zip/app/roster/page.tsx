'use client';
import {useEffect,useMemo,useState} from 'react';
import Link from 'next/link';
import {getRoster,removeRosterEntry,isCloudRoster,type RosterEntry} from '@/lib/roster';
import type {Character} from '@/lib/types';

type Row=RosterEntry&{character?:Character};
export default function Roster(){
 const [rows,setRows]=useState<Row[]>([]),[q,setQ]=useState(''),[source,setSource]=useState('local');
 async function load(){const roster=await getRoster();setSource(await isCloudRoster()?'cloud':'device');const chars=await Promise.all(roster.map(async r=>{try{const res=await fetch('/api/characters/'+r.character_id);return {...r,character:res.ok?await res.json():undefined}}catch{return r}}));setRows(chars)}
 useEffect(()=>{load();const fn=()=>load();window.addEventListener('mff-roster-changed',fn);return()=>window.removeEventListener('mff-roster-changed',fn)},[]);
 const shown=useMemo(()=>rows.filter(r=>(r.character?.name||r.character_id).toLowerCase().includes(q.toLowerCase())),[rows,q]);
 return <main className="rosterPage"><section className="rosterHero"><p className="eyebrow">PLAYER ROSTER</p><h1>My characters</h1><p>Track what you actually own so future recommendations can answer <b>who on your account</b> can clear a stage.</p><div className="rosterSummary"><b>{rows.length}</b><span>owned characters</span><em>{source==='cloud'?'☁ Cloud roster':'▣ Saved on this device'}</em></div><input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search my roster…"/></section>
  {!rows.length&&<div className="empty"><h2>Your roster is empty</h2><p>Open a character from the database and choose <b>Add to roster</b>.</p><Link className="primary" href="/">Browse characters</Link></div>}
  <section className="rosterGrid">{shown.map(r=><article className="rosterCard" key={r.character_id}><img src={r.character?.image||''} alt=""/><div className="rosterInfo"><div><b>{r.character?.name||r.character_id}</b><small>{r.tier||'Tier not set'}{r.level?` · Lv. ${r.level}`:''}</small></div><p>{r.uniform_id?(r.character?.uniforms?.find(u=>u.uniform_id===r.uniform_id)?.uniform_name||'Saved uniform'):(r.character?.latestUniform||'No current uniform listed')}</p><div className="rosterMeta"><span>{r.ctp||'No CTP set'}</span><span>{r.artifact_owned?'Artifact owned':'Artifact not marked'}</span></div>{r.notes&&<blockquote>{r.notes}</blockquote>}</div><button className="iconDanger" title="Remove" onClick={async()=>{await removeRosterEntry(r.character_id);load()}}>×</button></article>)}</section>
 </main>
}
