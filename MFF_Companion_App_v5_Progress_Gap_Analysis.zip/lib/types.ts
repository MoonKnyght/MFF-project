export type Uniform = { uniform_id:string; uniform_name:string; is_latest:boolean; chronology_status:string };
export type WblLink = { boss:string; stage_range:string; role:string };
export type StageLink = { stage:string|number; role?:string };
export type StoryLink = { month:string; story_stage:string };
export type Character = {
  id:string; name:string; aliases?:string|null; type?:string|null; gender?:string|null; allies?:string|null; image?:string|null;
  latestUniform?:string|null; highestTier?:string|null; attackType?:string|null; bestIso?:string|null; procRotation?:string|null;
  ctpRotation?:string|null; metaCtpPve?:string|null; offMetaCtpPve?:string|null; metaCtpPvp?:string|null; offMetaCtpPvp?:string|null;
  needsArtifact?:string|null; artifactName?:string|null; tierCategory?:string|null; tierRank?:number|null; tierTags?:string|null;
  t4?:Record<string, number|null>; uniforms?:Uniform[]; wbl?:WblLink[]; shadowland?:StageLink[]; dispatch?:StageLink[]; story?:StoryLink[];
};
